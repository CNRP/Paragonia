from django.contrib import admin
from .models import NewsPost

admin.site.register(NewsPost)