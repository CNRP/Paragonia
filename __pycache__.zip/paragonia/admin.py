from django.contrib import admin
from .models import GuideSection
from .models import HomeSection

admin.site.register(GuideSection)
admin.site.register(HomeSection)